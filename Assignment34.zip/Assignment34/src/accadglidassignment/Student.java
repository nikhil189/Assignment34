package accadglidassignment;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Student {
	String m_strStudentName;
	Date m_DOB;
	float m_fTotalMarks;

	public Student(String name, Date dob, float marks)
	{
		m_strStudentName = name;
		m_DOB = dob;
		m_fTotalMarks = marks;
	}
	public Student()
	{
		
	}
	public static void main(String ...k) throws IOException
	{
		try
		{
			Student objStudent1 = new Student("Hardik Pandya",new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH).parse("September 20, 1994"),88.0f);
			Student objStudent2 = new Student("Jaspreet Bumrah",new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH).parse("October 2, 1995"),78.0f);
			Student objStudent3 = new Student("Virat Kohli",new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH).parse("October 2, 1987"),98.0f);
			Student arrStudent[] = {objStudent1,objStudent2,objStudent3};
			Student objStudent = new Student();
			objStudent.printRankforStudents(arrStudent);
		}
		catch(Exception ex)
		{
			System.out.println("Exception" + ex.getStackTrace());
		}
	}
	
	void printRankforStudents(Student [] arrStudentRecord)
	{
		try
		{
			   for(int i=0; i <arrStudentRecord.length; i++)
			   {  
	                 for(int j=1; j < (arrStudentRecord.length-i); j++)
	                 {  
	                          if(arrStudentRecord[j-1].m_fTotalMarks < arrStudentRecord[j].m_fTotalMarks)
	                          {  
	                               Student  temp = arrStudentRecord[j-1];  
	                               arrStudentRecord[j-1] = arrStudentRecord[j];  
	                               arrStudentRecord[j] = temp;  
	                          }  
	                          
	                 }
			   }
			
			for(int iIndex =0; iIndex< arrStudentRecord.length;iIndex++)
			{
				System.out.println((iIndex+1)+" " + arrStudentRecord[iIndex].m_strStudentName +" " +arrStudentRecord[iIndex].m_DOB + " " + arrStudentRecord[iIndex].m_fTotalMarks);
			}
		}
		catch(Exception ex)
		{
			System.out.println("Exception" + ex.getStackTrace());
		}
		
	}
}
